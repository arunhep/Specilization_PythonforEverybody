<h1>Python 2.x is Deprecated</h2>
<p>
Hello - as of January 1, 2020, Python 2.x is no longer officially
supported.   This folder on the Python for Everybody web site
is old Python 2.x versions of some of the materials. You should
visit the Python 3.x versions of these materials.
</p>
<p>
<a href="../code3">Python 3.x Sample Code</a>
</p>
<p>
If you want to see the Python 2.x code, will be available in the
Python for Everybody github repo:
</p>
<p>
<a href="https://github.com/csev/py4e/tree/master/code">Github</a>
</p>
<p>
This Python 2.x material will be deleted from the github repository
on or after January 1, 2021.
</p>
